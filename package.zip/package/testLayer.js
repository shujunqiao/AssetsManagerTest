
var TestLayer = cc.Layer.extend({
    ctor:function() {
        this._super();
        cc.associateWithNative( this, cc.Layer );
        cc.log("ctor in testlayer.");
    },
    init:function () {

        //////////////////////////////
        // 1. super init first
        this._super();
        cc.log("init testlayer");

        // add a "close" icon to exit the progress. it's an autorelease object
        var closeItem = cc.MenuItemImage.create(
            "CloseNormal.png",
            "CloseSelected.png",
            function () {
                cc.log("click button in test.");
            },this);
        closeItem.setAnchorPoint(cc.p(0.5, 0.5));

        var menu = cc.Menu.create(closeItem);
        menu.setPosition(cc.p(0, 0));
        this.addChild(menu, 1);
        closeItem.setPosition(cc.p(100, 120));

        //hello test
        this.helloLabel = cc.LabelTTF.create("this is test layer!", "Arial", 38);
        // position the label on the center of the screen
        this.helloLabel.setPosition(cc.p(size.width / 2, size.height - 40));
        // add the label as a child to this layer
        this.addChild(this.helloLabel, 5);
        return true;
    }

});
